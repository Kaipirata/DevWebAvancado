const mongoose = require('mongoose');

const assinanteSchema = new mongoose.Schema({
    id: {type: Number,
    unique: true},
    nome: String,
    sobrenome: String,
    nascimento : Date,
    telefone: Number,
    endereco: String, 
    cidade: String,
    estado: String,
    status : Boolean,
    imagem: {
        data: Buffer, // Dados binários da imagem
        contentType: String // Tipo de conteúdo da imagem (ex: "image/jpeg", "image/png", etc.)
    }
});

module.exports = mongoose.model('assinantes', assinanteSchema);
