const assinanteModel = require('../models/assinanteModel');
const fs = require('fs');

class AssinanteController {

    async salvar(req, res) {
        let assinante = req.body;

        try {

            // Obter os dados da imagem
            const imagemPath = req.body.imagem;
            const imagemData = fs.readFileSync(imagemPath);

            // Definir os dados da imagem no objeto do assinante
            assinante.imagem = {
                data: imagemData,
                contentType: 'image/jpg' // Substitua pelo tipo de conteúdo correto da sua imagem
            };

            const max = await assinanteModel.findOne({}).sort({ id: -1 });
            assinante.id = max == null ? 1 : max.id + 1;
            const resultado = await assinanteModel.create(assinante);
            res.status(201).json(resultado);

        } catch (error) {
            console.error(error)
            res.status(500).json({ mensagem: 'Erro ao realizar cadastro do assinante.' })
        }
    }

    async listar(req, res) {

        try {
            const resultado = await assinanteModel.find({});

            if (!resultado) {
                res.status(404).json({ mensagem: 'Nenhum assinante encontrado!' })
            } else {
                res.status(200).json(resultado);
            }
        } catch (error) {
            console.error(error)
            res.status(500).json({ mensagem: 'Erro durante a listagem.' })
        }
    }

    async buscarPorId(req, res) {
        const id = req.params.id;

        try {
            const resultado = await assinanteModel.findOne({ 'id': id });

            if (!resultado) {
                res.status(404).json({ mensagem: `Assinante com ID: ${id} não encontrado!` })
            } else {
                res.status(200).json(resultado);
            }
        } catch (error) {
            console.error(error)
            res.status(500).json({ mensagem: 'Erro ao realizar busca por ID.' })
        }
    }

    async buscarPorNome(req, res) {
        const nome = req.params.nome;

        try {
            const resultado = await assinanteModel.findOne({ 'nome': nome });

            if (!resultado) {
                res.status(404).json({ mensagem: `Nenhum assinante com nome: ${nome} encontrado!` })
            } else {
                res.status(200).json(resultado);
            }
        } catch (error) {
            console.error(error)
            res.status(500).json({ mensagem: 'Erro ao realizar busca por nome.' })
        }
    }


    async buscarPorSobrenome(req, res) {
        const sobrenome = req.params.sobrenome;

        try {
            const resultado = await assinanteModel.find({ 'sobrenome': sobrenome });

            if (!resultado) {
                res.status(404).json({ mensagem: `Nenhum assinante com sobrenome: ${sobrenome} encontrado!` })
            } else {
                res.status(200).json(resultado);
            }
        } catch (error) {
            console.error(error)
            res.status(500).json({ mensagem: 'Erro ao realizar busca por sobrenome.' })
        }
    }

    async buscarPorCidade(req, res) {
        const cidade = req.params.cidade;

        try {
            const resultado = await assinanteModel.find({ 'cidade': cidade });
            if (!resultado) {
                res.status(404).json({ mensagem: `Nenhum assinante com a cidade: ${cidade} encontrado!` })
            } else {
                res.status(200).json(resultado);
            }
        } catch (error) {
            console.error(error)
            res.status(500).json({ mensagem: 'Erro ao realizar busca por cidade.' })
        }
    }

    async buscarPorEstado(req, res) {
        const estado = req.params.estado;

        try {
            const resultado = await assinanteModel.find({ 'estado': estado });

            if (!resultado) {
                res.status(404).json({ mensagem: `Nenhum assinante com o estado: ${estado} encontrado!` })
            } else {
                res.status(200).json(resultado);
            }
        } catch (error) {
            console.error(error)
            res.status(500).json({ mensagem: 'Erro ao realizar busca por estado.' })
        }
    }

    async buscarPorStatus(req, res) {
        const status = req.params.status;

        try {
            const resultado = await assinanteModel.find({ 'status': status });

            if (!resultado) {
                res.status(404).json({ mensagem: `Nenhum assinante com o status da conta: ${status} encontrado!` })
            } else {
                res.status(200).json(resultado);
            }
        } catch (error) {
            console.error(error)
            res.status(500).json({ mensagem: 'Erro ao realizar busca por status.' })
        }
    }

    async atualizar(req, res) {
        const id = req.params.id;
    
        try {
            const assinanteExistente = await assinanteModel.findOne({ 'id': id });
    
            if (!assinanteExistente) {
                res.status(404).json({ mensagem: `Nenhum assinante com o ID: ${id} encontrado para alteração!` });
                return;
            }
    
            const _id = String(assinanteExistente._id);
            const atualizacao = req.body;
    
            // Verifica se há um campo 'imagem' na requisição PUT
            if (req.body.imagem) {
                try {
                    const imagemPath = req.body.imagem;
                    const imagemData = fs.readFileSync(imagemPath);
    
                    // Atualiza os dados da imagem no objeto de atualização
                    atualizacao.imagem = {
                        data: imagemData,
                        contentType: 'image/jpg' // Substitua pelo tipo de conteúdo correto da sua imagem
                    };
                } catch (error) {
                    console.error(error);
                    res.status(500).json({ mensagem: 'Erro ao carregar a imagem.' });
                    return;
                }
            }
    
            await assinanteModel.findByIdAndUpdate(String(_id), atualizacao);
    
            res.status(200).json({ mensagem: 'Assinante atualizado com sucesso' });
        } catch (error) {
            console.error(error);
            res.status(500).json({ mensagem: 'Erro ao realizar alteração de assinante.' });
        }
    }

    async excluir(req, res) {
        const id = req.params.id;

        try {
            const _id = String((await assinanteModel.findOne({ 'id': id }))._id);
            await assinanteModel.findByIdAndRemove(String(_id));

            if (!_id) {
                res.status(404).json({ mensagem: `Nenhum assinante com o ID: ${_id} encontrado para ser excluido!` })
            } else {
                res.status(200).json({ mensagem: `Assinante excluido com sucesso` });
            }
        } catch (error) {
            console.error(error)
            res.status(500).json({ mensagem: 'Erro ao excluir o assinante.' })
        }
    }
}

module.exports = new AssinanteController();
