const express = require('express');
const router = express.Router();
const assinanteController = require('../controllers/assinanteController');

router.get('/', assinanteController.listar);
router.post('/', assinanteController.salvar);
router.get('/id/:id', assinanteController.buscarPorId);
router.get('/nome/:nome', assinanteController.buscarPorNome);
router.get('/sobrenome/:sobrenome', assinanteController.buscarPorSobrenome);
router.get('/cidade/:cidade', assinanteController.buscarPorCidade);
router.get('/estado/:estado', assinanteController.buscarPorEstado);
router.get('/status/:status', assinanteController.buscarPorStatus);
router.put('/:id', assinanteController.atualizar);
router.delete('/:id', assinanteController.excluir);


//Exemplo de post
// {
//     "nome": "João",
//     "sobrenome": "do Pé",
//     "nascimento": "1997-10-12",
//     "telefone": 00999887777,
//     "endereco": "Endereço Teste",
//     "cidade": "Curitiba",
//     "estados": "Parana",
//     "status": true,
//     "imagem":"C:/temp/foto.jpg"
//   }


module.exports = router;
